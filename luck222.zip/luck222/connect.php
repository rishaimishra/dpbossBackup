<?php
//establish a new connection 

//establish a db connection
$db= mysqli_connect("localhost","root","asdf@1234","dpboss_forum");






	

	
